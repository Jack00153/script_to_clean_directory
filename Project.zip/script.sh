#!/bin/bash

while true
do

a="*.sh"
b="*.sql"
c=$(du -k "/home/jack/test/logs" | awk '{print $1}' | sed 's/%//g')
d=$(df -h | grep "^/dev/mapper/centos-root" | awk '{print $5}' | sed 's/%//g')

find /home/jack/test/logs -exec du -s -h {} \; > /home/jack/test/logs_1.txt

mv /home/jack/test/logs/$a /home/jack/test/folder_with_format
mv /home/jack/test/logs/$b /home/jack/test/folder_with_format

if [ $c -ge 30 ];
then

echo 'more than 30K in /home/jack/test/logs' > /home/jack/test/space_K.log

else

echo 'less than 30K in /home/jack/test/logs' > /home/jack/test/space_K.log
fi

if [ $d -ge 36 ];
then

echo 'more than 36% in /home/jack/test/logs' > /home/jack/test/space_%.log

else

echo 'less than 36% in /home/jack/test/logs' > /home/jack/test/space_%.log
fi

find /home/jack/test/logs/* -cmin +1 -type f -delete

find /home/jack/test/logs -exec du -s -h {} \; > /home/jack/test/logs_2.txt

echo 'space occupancy in /home/jack/test/logs -' $c'K'
echo 'total percentage of space used in /home/jack/test/logs -' $d'%'

sleep 1
done

